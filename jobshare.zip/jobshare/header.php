<div class="grid-container">
  <div class="header"><img src="images/logo.png" style="height: 100px;width: 100px;padding:10px"></div>
  <div class="job">Jobs Here</div>
  <div class="fwhite" style="padding-top: 6%">
    <a href="clienthome.php" class="button button1" style="display:inline-flex;align-items:center;">Home</a>
    <button class="button button1" id="Btn">Login</button>
    <button class="button button1" id="Btn1">Signup</button>
  </div>
</div>