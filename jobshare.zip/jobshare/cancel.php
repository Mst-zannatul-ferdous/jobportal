<?php
echo "Payment canceled. You may return to the job page and try again.";
?>